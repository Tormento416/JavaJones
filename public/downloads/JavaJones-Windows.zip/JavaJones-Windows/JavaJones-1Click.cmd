@echo off
title Java Jones: JavaScript Espresso Empire
echo Starting Java Jones Coffee Shop...
start "" "%~dp0index.html"
exit
