JAVA JONES: JAVASCRIPT ESPRESSO EMPIRE - WINDOWS DESKTOP EDITION
---------------------------------------------------------------
How to Play:
1. Double-click "JavaJones-Launcher.bat" (or "index.html")
2. The game will open instantly in your browser!
3. Enjoy offline 28-day campaign with zero installation needed.
