JAVA JONES: JAVASCRIPT ESPRESSO EMPIRE - MAC DESKTOP EDITION
------------------------------------------------------------
How to Play:
1. Double-click "JavaJones-Launcher.command" (or "index.html")
2. The game will launch automatically!
3. Full offline 28-day campaign with zero installation needed.
